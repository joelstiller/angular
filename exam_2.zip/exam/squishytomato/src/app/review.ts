export class Review {
  _id: string;
  user: string;
  review: string;
  stars: number;
  movieID: string;
}
